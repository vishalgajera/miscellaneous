package com.confidential;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieReadServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieReadServiceApplication.class, args);
	}

}
