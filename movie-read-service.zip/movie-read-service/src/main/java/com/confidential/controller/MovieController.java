package com.confidential.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.confidential.dto.RestResponse;
import com.confidential.service.MovieReadService;

@RestController
@RequestMapping("/movie")
public class MovieController {

	@Autowired
	private MovieReadService movieReadService;
	
	@GetMapping("/{theaterId}")
	public ResponseEntity<RestResponse> fetchListOfMovieHostByTheater(@PathVariable Long theaterId) {
		return  new ResponseEntity<>(movieReadService.findAllMoviesByTheater(theaterId), HttpStatus.OK);
	} 
	
}
