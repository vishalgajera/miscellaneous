package com.confidential.service;

import com.confidential.dto.RestResponse;

public interface MovieReadService {

	public RestResponse findAllMoviesByTheater(Long theaterId);
	
}
