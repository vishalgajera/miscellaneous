package com.confidential.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.confidential.dto.RestResponse;
import com.confidential.repository.MovieRepository;
import com.confidential.service.MovieReadService;

@Service
public class MovieReadServiceImpl implements MovieReadService {

	@Autowired
	private MovieRepository movieRepository;

	@Override
	public RestResponse findAllMoviesByTheater(Long theaterId) {
		return new RestResponse("Success", movieRepository.findAllByTheaterTheaterId(theaterId), null);
	}
	
	
	
}
