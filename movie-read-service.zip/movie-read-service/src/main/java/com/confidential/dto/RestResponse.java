package com.confidential.dto;

import lombok.Data;

@Data
public class RestResponse {

	  private String status;

	  private Object responseBody;

	  private String errorMessage;
	  
	  public RestResponse(String status, Object responseBody, String errorMessage) {
		  this.status = status;
		  this.responseBody = responseBody;
		  this.errorMessage = errorMessage;
	  }

}
