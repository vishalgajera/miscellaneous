package com.confidential.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import lombok.Data;

@Entity
@Table(name = "Movies")
@Data
public class Movie {
	
	  @Id
	  @Column(name = "movie_id")
	  private Long movieId;

	  @ManyToOne(fetch = FetchType.LAZY)
	  @JoinColumn(name = "theater_id")
	  @OnDelete(action = OnDeleteAction.CASCADE)
	  private Theater theater;

	  @Column(name = "movie_name")
	  private String movieName;

	  @Column(name = "start_date")
	  private Date startDate;
	  
	  @Column(name = "end_date")
	  private Date endDate;
	  
	  @Column(name = "language")
	  private String language;
	  
	  @Column(name = "banner_image")
	  private String movieBannerImage;

}
