package com.confidential.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "Theater")
@Data
public class Theater {
	
	  @Id
	  @Column(name = "theater_id")
	  private Long theaterId;
	  
	  @Column(name = "theatre_name")
	  private String theatreName;
	  
	  @Column(name = "city")
	  private String city;

}
